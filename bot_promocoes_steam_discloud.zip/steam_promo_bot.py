import discord
from discord.ext import commands, tasks
import aiohttp
import asyncio
import json
from datetime import datetime

# ==================== CARREGA CONFIGURAÇÃO ====================
def carregar_config():
    config = {}
    try:
        with open("config.txt", "r", encoding="utf-8") as f:
            for linha in f:
                linha = linha.strip()
                if "=" in linha and not linha.startswith("#"):
                    chave, valor = linha.split("=", 1)
                    config[chave.strip()] = valor.strip()
    except FileNotFoundError:
        print("Arquivo config.txt não encontrado!")
        exit()
    
    if "TOKEN" not in config or "CANAL_ID" not in config:
        print("Erro: TOKEN ou CANAL_ID não encontrados no config.txt")
        exit()
    
    return config

config = carregar_config()
TOKEN = config["TOKEN"]
CANAL_ID = int(config["CANAL_ID"])
MIN_DESCONTO = int(config.get("MIN_DESCONTO", 70))
INTERVALO_MINUTOS = int(config.get("INTERVALO_MINUTOS", 45))

# ======================================================

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

promos_ja_postadas = set()  # Guarda os dealIDs já postados para não repetir

HEADERS = {
    "User-Agent": "SteamPromoBot/1.0 (bot-discord-promocoes)"
}

async def buscar_promos_steam(session, min_desconto=70, limite=10):
    """Busca promoções da Steam via CheapShark API"""
    url = "https://www.cheapshark.com/api/1.0/deals"
    params = {
        "storeID": "1",          # 1 = Steam
        "onSale": "1",
        "sortBy": "Savings",     # Ordena pelos maiores descontos
        "pageSize": str(limite * 2)
    }

    try:
        async with session.get(url, params=params, headers=HEADERS) as resp:
            if resp.status != 200:
                print(f"Erro na API: {resp.status}")
                return []
            dados = await resp.json()
    except Exception as e:
        print(f"Erro ao buscar promos: {e}")
        return []

    promos = []
    for deal in dados:
        try:
            desconto = float(deal.get("savings", 0))
            if desconto >= min_desconto:
                promos.append({
                    "titulo": deal["title"],
                    "preco_atual": deal["salePrice"],
                    "preco_normal": deal["normalPrice"],
                    "desconto": round(desconto),
                    "deal_id": deal["dealID"],
                    "thumb": deal.get("thumb"),
                    "avaliacao": deal.get("steamRatingText") or "Sem avaliação",
                    "metacritic": deal.get("metacriticScore", "0"),
                    "steam_app_id": deal.get("steamAppID")
                })
        except:
            continue

    return promos[:limite]


def traduzir_avaliacao(avaliacao):
    """Traduz a avaliação da Steam para português"""
    traducoes = {
        "Overwhelmingly Positive": "Extremamente Positiva",
        "Very Positive": "Muito Positiva",
        "Positive": "Positiva",
        "Mostly Positive": "Predominantemente Positiva",
        "Mixed": "Mista",
        "Mostly Negative": "Predominantemente Negativa",
        "Negative": "Negativa",
        "Very Negative": "Muito Negativa",
        "Overwhelmingly Negative": "Extremamente Negativa",
        None: "Sem avaliação",
        "Sem avaliação": "Sem avaliação"
    }
    return traducoes.get(avaliacao, avaliacao or "Sem avaliação")


def criar_embed(promo):
    """Cria um embed bonito da promoção em português"""
    link = f"https://www.cheapshark.com/redirect?dealID={promo['deal_id']}"
    
    embed = discord.Embed(
        title=f"🔥 {promo['titulo']}",
        description=f"**{promo['desconto']}% de desconto** na Steam!",
        color=0x1b2838,  # Cor Steam
        url=link,
        timestamp=datetime.now()
    )
    
    embed.add_field(name="💰 Preço", value=f"~~${promo['preco_normal']}~~ → **${promo['preco_atual']}**", inline=True)
    embed.add_field(name="📉 Desconto", value=f"**{promo['desconto']}% OFF**", inline=True)
    embed.add_field(name="⭐ Avaliação na Steam", value=traduzir_avaliacao(promo['avaliacao']), inline=True)
    
    if promo['metacritic'] != "0":
        embed.add_field(name="🎮 Nota Metacritic", value=promo['metacritic'], inline=True)
    
    embed.add_field(name="🔗 Link para comprar", value=f"[Clique aqui para ir na Steam]({link})", inline=False)
    
    if promo['thumb']:
        embed.set_thumbnail(url=promo['thumb'])
    
    embed.set_footer(text="Promoções da Steam • Bot de Ofertas")
    return embed


@bot.event
async def on_ready():
    print(f"Bot online como {bot.user}")
    print(f"Monitorando promos Steam com {MIN_DESCONTO}%+ de desconto")
    verificar_promos.start()


@tasks.loop(minutes=INTERVALO_MINUTOS)
async def verificar_promos():
    """Verifica e posta novas promoções automaticamente"""
    canal = bot.get_channel(CANAL_ID)
    if not canal:
        print("Canal não encontrado!")
        return

    async with aiohttp.ClientSession() as session:
        promos = await buscar_promos_steam(session, MIN_DESCONTO, 15)

    novas = 0
    for promo in promos:
        if promo["deal_id"] not in promos_ja_postadas:
            embed = criar_embed(promo)
            try:
                await canal.send(
                    content=f"🎮 **Nova promoção absurda na Steam!** ({promo['desconto']}% de desconto)",
                    embed=embed
                )
                promos_ja_postadas.add(promo["deal_id"])
                novas += 1
                await asyncio.sleep(2)  # Evita rate limit
            except Exception as e:
                print(f"Erro ao enviar: {e}")

    if novas > 0:
        print(f"Postadas {novas} novas promoções")
    else:
        print("Nenhuma promoção nova encontrada")


@bot.command(name="promos")
async def promos(ctx, quantidade: int = 5):
    """Mostra as melhores promoções atuais da Steam"""
    if quantidade > 10:
        quantidade = 10
        
    async with aiohttp.ClientSession() as session:
        promos = await buscar_promos_steam(session, MIN_DESCONTO, quantidade)

    if not promos:
        await ctx.send("Nenhuma promoção com desconto alto encontrada no momento. Tenta de novo mais tarde!")
        return

    await ctx.send(f"**🔥 As melhores promoções da Steam com {MIN_DESCONTO}% ou mais de desconto:**")
    
    for promo in promos:
        embed = criar_embed(promo)
        await ctx.send(embed=embed)
        await asyncio.sleep(1)


@bot.command(name="status")
async def status(ctx):
    await ctx.send(
        f"✅ Bot online e funcionando!\n"
        f"Estou monitorando as promoções da Steam com descontos de **{MIN_DESCONTO}% ou mais**\n"
        f"Verificando novas ofertas a cada **{INTERVALO_MINUTOS} minutos**\n"
        f"Promoções já postadas até agora: **{len(promos_ja_postadas)}**"
    )


# ==================== INICIAR ====================
if __name__ == "__main__":
    bot.run(TOKEN)
