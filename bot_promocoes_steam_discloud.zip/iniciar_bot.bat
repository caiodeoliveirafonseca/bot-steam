@echo off
title Bot de Promocoes Steam
echo ========================================
echo    Bot de Promocoes da Steam
echo ========================================
echo.

echo Instalando/Atualizando bibliotecas necessarias...
echo.
pip install --upgrade discord.py aiohttp

echo.
echo ========================================
echo Iniciando o bot...
echo ========================================
echo.
python steam_promo_bot.py

echo.
echo ========================================
echo O bot foi encerrado.
echo Pressione qualquer tecla para fechar...
pause >nul
